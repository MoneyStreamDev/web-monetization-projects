const url = 'https://coil.com/settings'
chrome.tabs.create({ url })
