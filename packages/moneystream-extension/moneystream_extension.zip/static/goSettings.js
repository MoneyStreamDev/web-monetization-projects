const url = 'https://moneystream.com/settings'
chrome.tabs.create({ url })
